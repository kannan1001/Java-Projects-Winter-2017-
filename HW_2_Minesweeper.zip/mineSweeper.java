/* 
1.Name of program: simplified version of minesweeper
2.Programmer's name:Geerthana Kannan
3.Current Date:2/6/2017
4.Computer system and compiler you are using:Lenovo Windows 10 ,Eclipse compiler for Java
5.Brief description of the program : To play a simplified version of minesweeper
*/

public class mineSweeper {
	static final int minVal =5;
	static final int maxVal =15;

	public static void main(String[] args) {
		boolean[][] comp_game_grid;
		boolean[][] user_guess;
		boolean[][] results;

		int row_size = InputMethods.readInt("Enter the no.of.rows:", minVal, maxVal);
		int column_size = InputMethods
				.readInt(" Enter the no.of.columns: \n", minVal, maxVal);
		int no_of_spots = InputMethods.readInt(" Enter the no.of.spots to set: \n",
				row_size, ((row_size * column_size) / 2));
		
		comp_game_grid = allocate_Grid(row_size, column_size);
		user_guess = allocate_Grid(row_size, column_size);
		results = allocate_Grid(row_size, column_size);

		boolean flag = true;
		while (flag == true) {

			System.out.println("\n Try to guess where the "+no_of_spots+" mines have been placed.");
			setRandomValues(comp_game_grid, no_of_spots);
			
			setInputValues(user_guess, no_of_spots, row_size, column_size);
			compareGrids(comp_game_grid, user_guess, results);

			System.out.println("Your guesses");
			display_Grid(user_guess, 'G');

			System.out.println("Game Mines");
			display_Grid(comp_game_grid, '*');

			System.out.println("Your matches");
			display_Grid(results, 'M');
			
			flag = InputMethods.wantsToRepeat();
		}
	}
	public static boolean[][] allocate_Grid(int row_size, int column_size) {
		if (row_size < 0) {
			row_size = 1;
		}
		if (column_size < 0) {
			column_size = 1;
		}
		boolean[][] grid = new boolean[row_size][column_size];
		return grid;
	}

	public static void initGrid(boolean[][] resetArray) {
		for (int i = 0; i < resetArray.length; i++) {
			for (int j = 0; j < resetArray[i].length; j++) {
				resetArray[i][j] = false;
			}
		}
	}

	public static boolean[][] setRandomValues(boolean[][] grid, int no_of_spots) {
		initGrid(grid);
		for (int i = 0; i < no_of_spots; i++) {
			int randRow = (int) (Math.random() * ((grid.length - 1) - 0 + 1)) + 0;
			int randColumn = (int) (Math.random() * ((grid[0].length - 1) - 0 + 1)) + 0;
			int tempIter = i;
			if (grid[randRow][randColumn] != true) {
				grid[randRow][randColumn] = true;
			} else {
				i = tempIter - 1;
			}
		}
		return grid;
	}

	public static boolean[][] setInputValues(boolean[][] grid, int no_of_spots,
			int rowSize, int colSize) {
		initGrid(grid);
		for (int i = 0; i < no_of_spots; i++) {
			int tempIter = i;
			int row = InputMethods.readInt("For mine," + i
					+ ", Enter row index:", 0, rowSize - 1);
			int column = InputMethods.readInt( " Enter column index:", 0, colSize - 1);
			if (grid[row][column] != true) {
				grid[row][column] = true;
			} else {
				System.out.print("Row Index " + row + " and col index"+ column+ " has already been entered. Please enter a new value\n");
				i = tempIter - 1;
			}
		}
		return grid;
	}

	public static void compareGrids(boolean[][] comp_game_grid,
			boolean[][] user_guess, boolean[][] results) {
		initGrid(results);
		for (int i = 0; i < results.length; i++) {
			for (int j = 0; j < results[0].length; j++) {
				if (comp_game_grid[i][j] == true && user_guess[i][j] == true) {
					results[i][j] = true;
				}
			}
		}
	}

	public static void display_Grid(boolean[][] grid, char a) {
		for (int i = 0; i < grid.length; i++) {
			System.out.print("|");
			for (int j = 0; j < grid[i].length; j++) {
				if (grid[i][j] == true) {
					System.out.print(" " + a + " ");
				} else {
					System.out.print("   ");
				}
			}
			System.out.print("|\n");
		}
		System.out.println("\n");

	}
}

//Output:
//Enter the no.of.rows:4
//Input out of range, must be >= 5 and <= 15
//Enter the no.of.rows:5
// Enter the no.of.columns: 
//16
//Input out of range, must be >= 5 and <= 15
// Enter the no.of.columns: 
//7
// Enter the no.of.spots to set: 
//8
//
// Try to guess where the 8 mines have been placed.
//For mine,0, Enter row index:0
// Enter column index:0
//For mine,1, Enter row index:8
//Input out of range, must be >= 0 and <= 4
//For mine,1, Enter row index:0
// Enter column index:12
//Input out of range, must be >= 0 and <= 6
// Enter column index:3
//For mine,2, Enter row index:0
// Enter column index:0
//Row Index 0 and col index0 has already been entered. Please enter a new value
//For mine,2, Enter row index:0
// Enter column index:1
//For mine,3, Enter row index:0
// Enter column index:1
//Row Index 0 and col index1 has already been entered. Please enter a new value
//For mine,3, Enter row index:0
// Enter column index:4
//For mine,4, Enter row index:0
// Enter column index:5
//For mine,5, Enter row index:0
// Enter column index:6
//For mine,6, Enter row index:0
// Enter column index:7
//Input out of range, must be >= 0 and <= 6
// Enter column index:0
//Row Index 0 and col index0 has already been entered. Please enter a new value
//For mine,6, Enter row index:4
// Enter column index:0
//For mine,7, Enter row index:4
// Enter column index:4
//Your guesses
//| G  G     G  G  G  G |
//|                     |
//|                     |
//|                     |
//| G           G       |
//
//
//Game Mines
//| *           *     * |
//|       *     *       |
//| *                   |
//|                   * |
//| *                   |
//
//
//Your matches
//| M           M     M |
//|                     |
//|                     |
//|                     |
//| M                   |
//
//
//Do you want to Repeat?
//y
//
// Try to guess where the 8 mines have been placed.
//For mine,0, Enter row index:0
// Enter column index:0
//For mine,1, Enter row index:1
// Enter column index:1
//For mine,2, Enter row index:2
// Enter column index:2
//For mine,3, Enter row index:3
// Enter column index:3
//For mine,4, Enter row index:4
// Enter column index:4
//For mine,5, Enter row index:5
//Input out of range, must be >= 0 and <= 4
//For mine,5, Enter row index:4
// Enter column index:9
//Input out of range, must be >= 0 and <= 6
// Enter column index:4
//Row Index 4 and col index4 has already been entered. Please enter a new value
//For mine,5, Enter row index:4
// Enter column index:1
//For mine,6, Enter row index:0
// Enter column index:3
//For mine,7, Enter row index:2
// Enter column index:3
//Your guesses
//| G        G          |
//|    G                |
//|       G  G          |
//|          G          |
//|    G        G       |
//
//
//Game Mines
//|          *  *       |
//| *        *          |
//| *                   |
//|       *             |
//|          *     *    |
//
//
//Your matches
//|          M          |
//|                     |
//|                     |
//|                     |
//|                     |
//
//
//Do you want to Repeat?
//y
//
// Try to guess where the 8 mines have been placed.
//For mine,0, Enter row index:-1
//Input out of range, must be >= 0 and <= 4
//For mine,0, Enter row index:-2
//Input out of range, must be >= 0 and <= 4
//For mine,0, Enter row index:5
//Input out of range, must be >= 0 and <= 4
//For mine,0, Enter row index:0
// Enter column index:-5
//Input out of range, must be >= 0 and <= 6
// Enter column index:-1
//Input out of range, must be >= 0 and <= 6
// Enter column index:0
//For mine,1, Enter row index:10
//Input out of range, must be >= 0 and <= 4
//For mine,1, Enter row index:4
// Enter column index:12
//Input out of range, must be >= 0 and <= 6
// Enter column index:6
//For mine,2, Enter row index:-9
//Input out of range, must be >= 0 and <= 4
//For mine,2, Enter row index:-8
//Input out of range, must be >= 0 and <= 4
//For mine,2, Enter row index:-7
//Input out of range, must be >= 0 and <= 4
//For mine,2, Enter row index:0
// Enter column index:-9
//Input out of range, must be >= 0 and <= 6
// Enter column index:-8
//Input out of range, must be >= 0 and <= 6
// Enter column index:-7
//Input out of range, must be >= 0 and <= 6
// Enter column index:0
//Row Index 0 and col index0 has already been entered. Please enter a new value
//For mine,2, Enter row index:1
// Enter column index:1
//For mine,3, Enter row index:2
// Enter column index:3
//For mine,4, Enter row index:3
// Enter column index:2
//For mine,5, Enter row index:1
// Enter column index:4
//For mine,6, Enter row index:4
// Enter column index:1
//For mine,7, Enter row index:5
//Input out of range, must be >= 0 and <= 4
//For mine,7, Enter row index:4
// Enter column index:4
//Your guesses
//| G                   |
//|    G        G       |
//|          G          |
//|       G             |
//|    G        G     G |
//
//
//Game Mines
//|          *     *    |
//|       *  *          |
//|    *                |
//| *     *             |
//|                   * |
//
//
//Your matches
//|                     |
//|                     |
//|                     |
//|       M             |
//|                   M |
//
//
//Do you want to Repeat?
//n



